import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-secret-lock-type',
  templateUrl: './secret-lock-type.component.html',
  styleUrls: ['./secret-lock-type.component.css']
})
export class SecretLockTypeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
