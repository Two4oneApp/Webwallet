import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-secret-proof',
  templateUrl: './secret-proof.component.html',
  styleUrls: ['./secret-proof.component.css']
})
export class SecretProofComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
