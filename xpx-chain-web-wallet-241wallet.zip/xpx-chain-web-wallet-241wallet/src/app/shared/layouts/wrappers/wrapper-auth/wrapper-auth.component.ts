import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wrapper-auth',
  templateUrl: './wrapper-auth.component.html',
  styleUrls: ['./wrapper-auth.component.css']
})
export class WrapperAuthComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
