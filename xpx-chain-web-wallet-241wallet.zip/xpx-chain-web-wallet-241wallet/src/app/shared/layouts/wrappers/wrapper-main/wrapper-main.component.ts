import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wrapper-main',
  templateUrl: './wrapper-main.component.html',
  styleUrls: ['./wrapper-main.component.css']
})
export class WrapperMainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
