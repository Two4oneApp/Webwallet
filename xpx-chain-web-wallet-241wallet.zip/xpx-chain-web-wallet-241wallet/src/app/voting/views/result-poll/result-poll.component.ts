import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-result-poll',
  templateUrl: './result-poll.component.html',
  styleUrls: ['./result-poll.component.css']
})
export class ResultPollComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
